<template>
    <div>
       <h1>SKU管理</h1>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>