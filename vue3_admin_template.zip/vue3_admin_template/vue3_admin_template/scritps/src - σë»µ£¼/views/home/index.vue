<template>
  <div>
    <h1>我是一级路由展示登录成功以后的数据</h1>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>